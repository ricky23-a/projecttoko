<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<div class="container-fluid py-4">
    <h2 class="mb-4">Dashboard</h2>

    <!-- Row Kartu Statistik -->
    <div class="row g-4 mb-4">
        <!-- Kartu Jumlah Jenis Buah -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="bg-success text-white rounded-circle p-3">
                            <i class="bi bi-apple fs-4"></i>
                        </div>
                    </div>
                    <div>
                        <h6 class="mb-1">Jumlah Jenis Buah</h6>
                        <h3 class="mb-0 fw-bold">500</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kartu Jumlah Jenis Barang -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="bg-primary text-white rounded-circle p-3">
                            <i class="bi bi-box-seam fs-4"></i>
                        </div>
                    </div>
                    <div>
                        <h6 class="mb-1">Jumlah Jenis Barang</h6>
                        <h3 class="mb-0 fw-bold">500</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kartu Tambahan (Contoh) -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="bg-warning text-white rounded-circle p-3">
                            <i class="bi bi-cart4 fs-4"></i>
                        </div>
                    </div>
                    <div>
                        <h6 class="mb-1">Total Transaksi</h6>
                        <h3 class="mb-0 fw-bold">120</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Kartu Sambutan -->
    <div class="card shadow-sm border-0">
        <div class="card-body">
            <h5 class="card-title">Selamat Datang di Sistem Informasi Fruitin</h5>
            <p class="card-text">Gunakan menu navigasi di sebelah kiri untuk mengelola data buah, barang, dan transaksi dengan mudah dan efisien.</p>
        </div>
    </div>
</div>
